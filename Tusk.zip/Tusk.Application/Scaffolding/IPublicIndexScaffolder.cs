namespace Tusk.Application.Scaffolding;

public interface IPublicIndexScaffolder
{
    void EnsureDefaultPublicIndex(string cwd);
}
